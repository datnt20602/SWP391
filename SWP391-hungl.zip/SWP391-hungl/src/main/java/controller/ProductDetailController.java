package controller;

import Dal.DAOProduct;
import Model.Product;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;

@WebServlet(name = "ProductDetailController", value = "/productdetail")
public class ProductDetailController extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            int productId = Integer.parseInt(request.getParameter("productId"));
            request.getSession().setAttribute("urlHistory", "detail?productId="+productId);
            DAOProduct pdb = new DAOProduct();
            Product product = pdb.getProductById(productId);
            List<Product> listLast = pdb.getAllProductsLast();
            request.setAttribute("product", product);
            request.setAttribute("listLast", listLast);
            request.getRequestDispatcher("product-detail.jsp").forward(request, response);
        }
    }
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("template/front-end/product-detail.jsp").forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("template/front-end/product-detail.jsp").forward(request,response);
    }
}