package Dal;

public class DAOWishlist extends  DBContext{
}
