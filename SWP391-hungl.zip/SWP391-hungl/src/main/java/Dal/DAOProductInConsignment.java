package Dal;

public class DAOProductInConsignment extends DBContext{

}
