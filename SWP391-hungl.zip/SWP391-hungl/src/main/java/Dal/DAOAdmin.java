package Dal;

public class DAOAdmin extends DBContext{
    
}
